﻿namespace AWSLambdas.Models
{
    public class EmployeeMessageModel
    {
        public string Message { get; set; }

    }
}
