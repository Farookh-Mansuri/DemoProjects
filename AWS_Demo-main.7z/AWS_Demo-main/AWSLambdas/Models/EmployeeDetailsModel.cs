﻿namespace AWSLambdas.Models
{
    public class EmployeeDetailsModel
    {
        public string Name { get; set; }
        public string Designation { get; set; }
        public int Id { get; set; }

    }
}
